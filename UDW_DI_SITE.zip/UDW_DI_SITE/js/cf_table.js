document.addEventListener('DOMContentLoaded', function() {
    // Tab switching functionality
    const tabs = document.querySelectorAll('.tab');
    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            // Remove active class from all tabs
            tabs.forEach(t => t.classList.remove('active'));
            // Add active class to clicked tab
            this.classList.add('active');
            // In a real app, you would show/hide content based on the selected tab
        });
    });
    
    // Add button functionality
    const addButton = document.querySelector('.git-btn');
    if (addButton) {
        addButton.addEventListener('click', function() {
            // Add repository logic would go here
            console.log('Repository added');
        });
    }
    
    // Generate button functionality
    const generateButton = document.querySelector('.btn-generate');
    if (generateButton) {
        generateButton.addEventListener('click', function() {
            // Generation logic would go here
            console.log('Generating table structure');
        });
    }
});