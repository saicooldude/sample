import teradatasql

def validate_teradata_connection(user_id, password):
    host = 'UDWPROD'
    database = 'UDWETLSRCREPVIEW'
    logmech = 'LDAP'
    
    try:
        # Create a connection to the Teradata database
        connection = teradatasql.connect(
            host=host,
            user=user_id,
            password=password,
            database=database,
            logmech=logmech
        )
        
        # Create a cursor object using the connection
        cursor = connection.cursor()
        
        # Validation 1: Check connection
        cursor.execute("SELECT 1")
        cursor.fetchall()
        
    except Exception as e:
        return False
    
    return True

