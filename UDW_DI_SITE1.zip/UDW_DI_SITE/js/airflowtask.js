document.addEventListener('DOMContentLoaded', function() {
    // Tab switching functionality
    const tabs = document.querySelectorAll('.tab');
    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const targetPage = this.getAttribute('data-target');
            if (targetPage && !this.classList.contains('active')) {
                window.location.href = `/${targetPage}`;
            }
        });
    });
    
    // Generate button functionality
    const generateButton = document.querySelector('.generate-btn');
    if (generateButton) {
        generateButton.addEventListener('click', function() {
            console.log('Generating Airflow DAG definition');
            updateDagCode();
        });
    }
    
    // Schedule input functionality - update hint based on cron expression
    const scheduleInput = document.querySelector('.input-group input[value="0 */12 * * *"]');
    const scheduleHint = document.querySelector('.schedule-hint');
    
    if (scheduleInput && scheduleHint) {
        scheduleInput.addEventListener('input', function() {
            const cronExpression = this.value.trim();
            let hint = '';
            
            // Simple cron interpreter
            if (cronExpression === '0 */12 * * *') {
                hint = 'Every 12 hours';
            } else if (cronExpression === '0 0 * * *') {
                hint = 'Daily at midnight';
            } else if (cronExpression === '0 0 * * MON') {
                hint = 'Every Monday at midnight';
            } else if (cronExpression === '0 0 1 * *') {
                hint = 'First day of the month';
            } else {
                hint = 'Custom schedule';
            }
            
            scheduleHint.textContent = hint;
        });
    }
    
    // Import button functionality
    const importButton = document.querySelector('.import-btn');
    if (importButton) {
        importButton.addEventListener('click', function() {
            console.log('Importing Airflow task data');
            // Add Airflow-specific import logic here
        });
    }
    
    // Export button functionality
    const exportButton = document.querySelector('.export-btn');
    if (exportButton) {
        exportButton.addEventListener('click', function() {
            console.log('Exporting Airflow task data');
            // Add Airflow-specific export logic here
        });
    }
});

// Function to update the DAG code based on form inputs
function updateDagCode() {
    const msId = document.getElementById('ms-id').value;
    const baseTable = document.getElementById('base-table').value;
    const srcSysCd = document.getElementById('src-sys-cd').value;
    const batchName = document.getElementById('batch-name').value;
    const dagNameInput = document.querySelector('.input-group input[value="GRU_ADJD_MCE_DAG"]');
    const scheduleInput = document.querySelector('.input-group input[value="0 */12 * * *"]');
    const envSelect = document.querySelector('.env-select');
    
    const dagName = dagNameInput ? dagNameInput.value : batchName + '_DAG';
    const schedule = scheduleInput ? scheduleInput.value : '0 */12 * * *';
    const environment = envSelect ? envSelect.value : 'dev';
    
    // Build DAG Python code
    const dagCode = `from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy_operator import DummyOperator
from datetime import datetime, timedelta

default_args = {
    'owner': '${msId}',
    'depends_on_past': False,
    'start_date': datetime(2023, 1, 1),
    'email': ['${msId}@company.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

dag = DAG(
    '${dagName}',
    default_args=default_args,
    description='DAG for ${srcSysCd} ${baseTable} ETL process',
    schedule_interval='${schedule}',
    catchup=False
)

start = DummyOperator(
    task_id='start',
    dag=dag
)

load_prebase = PythonOperator(
    task_id='load_prebase_table',
    python_callable=load_prebase_fn,
    op_kwargs={'src_sys_cd': '${srcSysCd}', 'table_name': '${baseTable}'},
    dag=dag
)

load_cf = PythonOperator(
    task_id='load_cf_table',
    python_callable=load_cf_fn,
    op_kwargs={'src_sys_cd': '${srcSysCd}', 'table_name': '${baseTable}'},
    dag=dag
)

end = DummyOperator(
    task_id='end',
    dag=dag
)

start >> load_prebase >> load_cf >> end`;

    // Update the code display
    const codeContent = document.getElementById('code-content');
    if (codeContent) {
        codeContent.textContent = dagCode;
    }
}