document.addEventListener('DOMContentLoaded', function() {
    // Tab switching functionality
    const tabs = document.querySelectorAll('.tab');
    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const targetPage = this.getAttribute('data-target');
            if (targetPage && !this.classList.contains('active')) {
                window.location.href = `/${targetPage}`;
            }
        });
    });
    
    // Table button functionality
    document.querySelectorAll('.table-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const tableId = parseInt(this.getAttribute('data-table-id'));
            showTableSQL(tableId);
        });
    });
    
    // Generate button functionality
    const generateButton = document.querySelector('.generate-btn');
    if (generateButton) {
        generateButton.addEventListener('click', function() {
            console.log('Generating CF SQL');
            // Add CF SQL-specific generation logic here
        });
    }
    
    // Import button functionality
    const importButton = document.querySelector('.import-btn');
    if (importButton) {
        importButton.addEventListener('click', function() {
            console.log('Importing CF SQL data');
            // Add CF SQL-specific import logic here
        });
    }
    
    // Export button functionality
    const exportButton = document.querySelector('.export-btn');
    if (exportButton) {
        exportButton.addEventListener('click', function() {
            console.log('Exporting CF SQL data');
            // Add CF SQL-specific export logic here
        });
    }
});

// Function to show SQL for a specific table
function showTableSQL(tableId) {
    const tablesData = window.tablesData || [];
    const tableData = tablesData.find(t => t.id === tableId);
    if (tableData) {
        document.getElementById('sql-content').textContent = tableData.sql;
        
        // Update active button
        document.querySelectorAll('.table-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`.table-btn[data-table-id="${tableId}"]`).classList.add('active');
    }
}