// Update the tabs event listener section to shake all invalid fields when clicking a tab

// Add click event listeners for tab navigation
const tabs = document.querySelectorAll('.tab');
tabs.forEach(tab => {
    tab.addEventListener('click', async function(event) {
        event.preventDefault();
        
        // Get all field values
        const msId = document.getElementById('ms-id').value;
        const password = document.getElementById('password').value;
        const baseTable = document.getElementById('base-table').value;
        const srcSysCd = document.getElementById('src-sys-cd').value;
        const batchName = document.getElementById('batch-name').value;
        
        try {
            const response = await fetch('/validate-all', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    ms_id: msId,
                    password: password,
                    base_table: baseTable,
                    src_sys_cd: srcSysCd,
                    batch_name: batchName
                }),
            });
            
            const result = await response.json();
            
            if (result.valid) {
                // Navigate to the linked page
                window.location.href = this.getAttribute('href');
            } else {
                // Remove all existing error messages
                document.querySelectorAll('.error-message').forEach(el => el.remove());
                
                // Show validation errors for each field
                for (const field in result.results) {
                    if (!result.results[field]) {
                        const element = document.getElementById(field);
                        if (element) {
                            // Add invalid styling
                            element.classList.add('invalid-input');
                            element.classList.add('shake');
                            
                            // Create and add error message
                            const errorMessage = document.createElement('div');
                            errorMessage.className = 'error-message';
                            errorMessage.textContent = result.messages[field];
                            element.parentNode.appendChild(errorMessage);
                            
                            // Remove shake after animation completes
                            setTimeout(() => {
                                element.classList.remove('shake');
                            }, 500);
                        }
                    }
                }
            }
        } catch (error) {
            console.error('Validation error:', error);
        }
    });
});

// Remove invalid-input class and error messages when user starts typing
document.querySelectorAll('input').forEach(input => {
    input.addEventListener('input', function() {
        this.classList.remove('invalid-input');
        const errorMessage = this.parentNode.querySelector('.error-message');
        if (errorMessage) {
            errorMessage.remove();
        }
    });
});