from flask import Flask, render_template, request, jsonify, redirect, url_for, session, flash
import json
from python.fetch_base_table_ddl import fetch_teradata_table_ddl
from python.Make_cf_table_ddl import create_cf_table_ddl
from python.validate_user_id_password import validate_teradata_connection
from python.Make_prebase_table_ddl import create_prebase_table_ddl

app = Flask(__name__)
app.secret_key = 'udw_di_tool_secret_key'  # Needed for session management
app.config['SESSION_TYPE'] = 'filesystem'  # More reliable session storage

# Validation functions (unchanged)
def validate_ms_id(ms_id):
    # MS ID must be at least 5 characters and alphanumeric
    if len(ms_id) < 5 or not ms_id.isalnum():
        return False
    return True

def validate_password(ms_id,password):
    # Password must be at least 8 characters
    if len(password) < 8:
        return False
    return validate_teradata_connection(ms_id,password)

def validate_base_table(base_table):
    # Base table must contain underscore and be uppercase
    if '_' not in base_table or base_table != base_table.upper():
        return False
    return True

def validate_src_sys_cd(src_sys_cd):
    # SRC_SYS_CD must be 3-4 uppercase letters
    if not (3 <= len(src_sys_cd) <= 4) or not src_sys_cd.isupper() or not src_sys_cd.isalpha():
        return False
    return True

def validate_batch_name(batch_name):
    # Batch name must contain underscore and be uppercase
    if '_' not in batch_name or batch_name != batch_name.upper():
        return False
    return True

@app.route('/')
def index():
    return render_template('front_page.html', 
                          validation_errors=session.pop('validation_errors', None),
                          ms_id=session.get('ms_id', 'cmanasa4'),
                          password='************',
                          base_table=session.get('base_table', 'ADJD_MCE_SRVC_NDC'),
                          src_sys_cd=session.get('src_sys_cd', 'GRU'),
                          batch_name=session.get('batch_name', 'GRU_ADJD_MCE'))

@app.route('/submit-form', methods=['POST'])
def submit_form():
    """Process form submission and handle validation before navigation"""
    
    # Get form data
    ms_id = request.form.get('ms_id', '')
    password = request.form.get('password', '')
    base_table = request.form.get('base_table', '')
    src_sys_cd = request.form.get('src_sys_cd', '')
    batch_name = request.form.get('batch_name', '')
    target_page = request.form.get('target_page', 'cftable')
    
    print(f"Form submission received for target: {target_page}")
    print(f"Form data: ms_id={ms_id}, base_table={base_table}, src_sys_cd={src_sys_cd}, batch_name={batch_name}")
    
    # Validate all inputs - now checking each item in comma-separated lists
    validation_results = {}
    validation_messages = {}
    
    # Validate MS ID
    ms_id_valid = validate_ms_id(ms_id)
    validation_results['ms-id'] = ms_id_valid
    if not ms_id_valid:
        validation_messages['ms-id'] = 'MS ID must be at least 5 alphanumeric characters'
    
    # Validate password
    password_valid = validate_password(ms_id,password)
    validation_results['password'] = password_valid
    if not password_valid:
        validation_messages['password'] = 'Password must be at least 8 characters'
    
    # Validate base table (each item in comma-separated list)
    base_table_items = [item.strip() for item in base_table.split(',')]
    base_table_valid = True
    for item in base_table_items:
        if not validate_base_table(item):
            base_table_valid = False
            break
    
    validation_results['base-table'] = base_table_valid
    if not base_table_valid:
        validation_messages['base-table'] = 'Each base table must contain underscore and be uppercase'
    
    # Validate src_sys_cd (each item in comma-separated list)
    src_sys_cd_items = [item.strip() for item in src_sys_cd.split(',')]
    src_sys_cd_valid = True
    for item in src_sys_cd_items:
        if not validate_src_sys_cd(item):
            src_sys_cd_valid = False
            break
            
    validation_results['src-sys-cd'] = src_sys_cd_valid
    if not src_sys_cd_valid:
        validation_messages['src-sys-cd'] = 'Each SRC_SYS_CD must be 3-4 uppercase letters'
    
    # Validate batch name (each item in comma-separated list)
    batch_name_items = [item.strip() for item in batch_name.split(',')]
    batch_name_valid = True
    for item in batch_name_items:
        if not validate_batch_name(item):
            batch_name_valid = False
            break
            
    validation_results['batch-name'] = batch_name_valid
    if not batch_name_valid:
        validation_messages['batch-name'] = 'Each batch name must contain underscore and be uppercase'
    
    # Check if the counts match
    if len(base_table_items) != len(src_sys_cd_items) or len(base_table_items) != len(batch_name_items):
        validation_results['general'] = False
        validation_messages['general'] = 'The number of BASE TABLEs, SRC_SYS_CDs, and BATCH NAMEs must be the same'
        all_valid = False
    else:
        all_valid = all(validation_results.values())
    
    # Store the values in session regardless of validation result
    session['ms_id'] = ms_id
    session['base_table'] = base_table
    session['src_sys_cd'] = src_sys_cd
    session['batch_name'] = batch_name
    session['password'] = password
    
    
    if all_valid:
        # Set validation success flag in session
        session['validation_passed'] = True
        print("Validation passed, redirecting to:", target_page)
        # Redirect to the target page
        return redirect(url_for(target_page))
    else:
        # Store validation errors in session
        session['validation_errors'] = validation_messages
        session['validation_passed'] = False
        print("Validation failed with errors:", validation_messages)
        # Redirect back to the form with errors
        return redirect(url_for('index'))

@app.route('/validate', methods=['POST'])
def validate():
    # Original API endpoint - still useful for AJAX validation
    data = request.json
    field = data.get('field')
    value = data.get('value')
    
    validation_result = {'valid': True, 'message': ''}
    
    if field == 'ms-id':
        validation_result['valid'] = validate_ms_id(value)
        validation_result['message'] = 'MS ID must be at least 5 alphanumeric characters'
    
    elif field == 'password':
        ms_id = session.get('ms_id', '')
        validation_result['valid'] = validate_password(ms_id, value)
        validation_result['message'] = 'Password must be at least 8 characters'
    
    elif field == 'base-table':
        # Validate each item in comma-separated list
        items = [item.strip() for item in value.split(',')]
        for item in items:
            if not validate_base_table(item):
                validation_result['valid'] = False
                break
        validation_result['message'] = 'Each base table must contain underscore and be uppercase'
    
    elif field == 'src-sys-cd':
        # Validate each item in comma-separated list
        items = [item.strip() for item in value.split(',')]
        for item in items:
            if not validate_src_sys_cd(item):
                validation_result['valid'] = False
                break
        validation_result['message'] = 'Each SRC_SYS_CD must be 3-4 uppercase letters'
    
    elif field == 'batch-name':
        # Validate each item in comma-separated list
        items = [item.strip() for item in value.split(',')]
        for item in items:
            if not validate_batch_name(item):
                validation_result['valid'] = False
                break
        validation_result['message'] = 'Each batch name must contain underscore and be uppercase'
    
    return jsonify(validation_result)

@app.route('/cftable')
def cftable():
    # Check if validation has been performed and passed
    if not session.get('validation_passed', False):
        print("Validation hasn't been passed, redirecting to index")
        # Set error message
        session['validation_errors'] = {
            'general': "Please complete the form validation before accessing CF Table"
        }
        # Redirect back to front page
        return redirect(url_for('index'))
    
    # Get values from session
    ms_id = session.get('ms_id')
    password = session.get('password')
    base_tables = [item.strip() for item in session.get('base_table', '').split(',')]
    src_sys_cds = [item.strip() for item in session.get('src_sys_cd', '').split(',')]
    batch_names = [item.strip() for item in session.get('batch_name', '').split(',')]
    
    # Generate SQL content for each table
    tables_data = []
    
    for i in range(len(base_tables)):
        base_table = base_tables[i]
        src_sys_cd = src_sys_cds[i] if i < len(src_sys_cds) else src_sys_cds[-1]
        batch_name = batch_names[i] if i < len(batch_names) else batch_names[-1]
        sql_content = fetch_teradata_table_ddl(
            host='UDWPROD',
            user=ms_id, 
            password=password,
            database='UDWBASE',
            logmech='LDAP',
            table_name=base_table
        )
        sql_content = create_cf_table_ddl(src_sys_cd, base_table, sql_content)
        
        # Add to tables data
        tables_data.append({
            'id': i,
            'name': base_table,
            'sql': sql_content,
            'src_sys_cd': src_sys_cd,
            'batch_name': batch_name
        })
    
    # Convert tables_data to JSON for JavaScript usage
    tables_json = json.dumps(tables_data)
    
    print(f"Rendering CF Table with {len(tables_data)} tables")
    
    return render_template('cf_table.html', 
                          ms_id=ms_id,
                          base_table=session.get('base_table'),
                          src_sys_cd=session.get('src_sys_cd'),
                          batch_name=session.get('batch_name'),
                          tables_data=tables_data,
                          tables_json=tables_json)

@app.route('/prebasetable')
def prebasetable():
    # Check if validation has been performed and passed
    if not session.get('validation_passed', False):
        print("Validation hasn't been passed, redirecting to index")
        # Set error message
        session['validation_errors'] = {
            'general': "Please complete the form validation before accessing Prebase Table"
        }
        # Redirect back to front page
        return redirect(url_for('index'))
    
    # Get values from session
    ms_id = session.get('ms_id')
    password = session.get('password')
    base_tables = [item.strip() for item in session.get('base_table', '').split(',')]
    src_sys_cds = [item.strip() for item in session.get('src_sys_cd', '').split(',')]
    batch_names = [item.strip() for item in session.get('batch_name', '').split(',')]
    
    # Generate SQL content for each table
    tables_data = []
    
    for i in range(len(base_tables)):
        base_table = base_tables[i]
        src_sys_cd = src_sys_cds[i] if i < len(src_sys_cds) else src_sys_cds[-1]
        batch_name = batch_names[i] if i < len(batch_names) else batch_names[-1]
        
        # Fetch the original table DDL
        sql_content = fetch_teradata_table_ddl(
            host='UDWPROD',
            user=ms_id, 
            password=password,
            database='UDWBASE',
            logmech='LDAP',
            table_name=base_table
        )
        
        # Transform to prebase table DDL
        sql_content = create_prebase_table_ddl(src_sys_cd, base_table, sql_content)
        
        # Add to tables data
        tables_data.append({
            'id': i,
            'name': base_table,
            'sql': sql_content,
            'src_sys_cd': src_sys_cd,
            'batch_name': batch_name
        })
    
    # Convert tables_data to JSON for JavaScript usage
    tables_json = json.dumps(tables_data)
    
    print(f"Rendering Prebase Table with {len(tables_data)} tables")
    
    return render_template('prebase_table.html', 
                          ms_id=ms_id,
                          base_table=session.get('base_table'),
                          src_sys_cd=session.get('src_sys_cd'),
                          batch_name=session.get('batch_name'),
                          tables_data=tables_data,
                          tables_json=tables_json)

@app.route('/cfsql')
def cfsql():
    # Check if validation has been performed and passed
    if not session.get('validation_passed', False):
        print("Validation hasn't been passed, redirecting to index")
        # Set error message
        session['validation_errors'] = {
            'general': "Please complete the form validation before accessing CF SQL"
        }
        # Redirect back to front page
        return redirect(url_for('index'))
    
    # Get values from session
    ms_id = session.get('ms_id')
    password = session.get('password')
    base_tables = [item.strip() for item in session.get('base_table', '').split(',')]
    src_sys_cds = [item.strip() for item in session.get('src_sys_cd', '').split(',')]
    batch_names = [item.strip() for item in session.get('batch_name', '').split(',')]
    
    # Generate SQL content for each table
    tables_data = []
    
    for i in range(len(base_tables)):
        base_table = base_tables[i]
        src_sys_cd = src_sys_cds[i] if i < len(src_sys_cds) else src_sys_cds[-1]
        batch_name = batch_names[i] if i < len(batch_names) else batch_names[-1]
        
        # Generate SQL for CF table
        sql_content = f"""INSERT INTO U2NETWORK.{src_sys_cd}_{base_table}_CF
SELECT
    BI,
    UDW_ADJD_MCE_ID,
    ADJD_MED_CLM_SRVC_LN_NUM,
    NDC_SEQ_ID,
    NDC_CHARSTR,
    UDW_CD,
    NDC_CD,
    NDC_QTY,
    NDC_UOM_CD,
    NDC_COST_AMT,
    PUBREL_CREAT_TS,
    PUBREL_UPDT_TS,
    UDW_BTCH_ID,
    UDW_CREAT_TS,
    UDW_SRC_SYS_CD
FROM
    UDWVIEW.{base_table}
WHERE
    UDW_SRC_SYS_CD = '{src_sys_cd}'
    AND UDW_CREAT_TS >= CURRENT_TIMESTAMP - INTERVAL '24' HOUR"""
        
        # Add to tables data
        tables_data.append({
            'id': i,
            'name': base_table,
            'sql': sql_content,
            'src_sys_cd': src_sys_cd,
            'batch_name': batch_name
        })
    
    # Convert tables_data to JSON for JavaScript usage
    tables_json = json.dumps(tables_data)
    
    print(f"Rendering CF SQL with {len(tables_data)} tables")
    
    return render_template('cfsql.html', 
                          ms_id=ms_id,
                          base_table=session.get('base_table'),
                          src_sys_cd=session.get('src_sys_cd'),
                          batch_name=session.get('batch_name'),
                          tables_data=tables_data,
                          tables_json=tables_json)

@app.route('/prebasesql')
def prebasesql():
    # Check if validation has been performed and passed
    if not session.get('validation_passed', False):
        print("Validation hasn't been passed, redirecting to index")
        # Set error message
        session['validation_errors'] = {
            'general': "Please complete the form validation before accessing Prebase SQL"
        }
        # Redirect back to front page
        return redirect(url_for('index'))
    
    # Get values from session
    ms_id = session.get('ms_id')
    password = session.get('password')
    base_tables = [item.strip() for item in session.get('base_table', '').split(',')]
    src_sys_cds = [item.strip() for item in session.get('src_sys_cd', '').split(',')]
    batch_names = [item.strip() for item in session.get('batch_name', '').split(',')]
    
    # Generate SQL content for each table
    tables_data = []
    
    for i in range(len(base_tables)):
        base_table = base_tables[i]
        src_sys_cd = src_sys_cds[i] if i < len(src_sys_cds) else src_sys_cds[-1]
        batch_name = batch_names[i] if i < len(batch_names) else batch_names[-1]
        
        # Generate SQL for prebase table
        sql_content = f"""INSERT INTO U2NETWORK.{src_sys_cd}_{base_table}_PREBASE
SELECT
    BI,
    UDW_ADJD_MCE_ID,
    ADJD_MED_CLM_SRVC_LN_NUM,
    NDC_SEQ_ID,
    NDC_CHARSTR,
    UDW_CD,
    NDC_CD,
    NDC_QTY,
    NDC_UOM_CD,
    NDC_COST_AMT,
    PUBREL_CREAT_TS,
    PUBREL_UPDT_TS,
    UDW_BTCH_ID,
    UDW_CREAT_TS,
    UDW_SRC_SYS_CD
FROM
    UDWETLSRCREPVIEW.{base_table}
WHERE
    UDW_SRC_SYS_CD = '{src_sys_cd}'
    AND UDW_CREAT_TS >= CURRENT_TIMESTAMP - INTERVAL '24' HOUR"""
        
        # Add to tables data
        tables_data.append({
            'id': i,
            'name': base_table,
            'sql': sql_content,
            'src_sys_cd': src_sys_cd,
            'batch_name': batch_name
        })
    
    # Convert tables_data to JSON for JavaScript usage
    tables_json = json.dumps(tables_data)
    
    print(f"Rendering Prebase SQL with {len(tables_data)} tables")
    
    return render_template('prebasesql.html', 
                          ms_id=ms_id,
                          base_table=session.get('base_table'),
                          src_sys_cd=session.get('src_sys_cd'),
                          batch_name=session.get('batch_name'),
                          tables_data=tables_data,
                          tables_json=tables_json)

@app.route('/airflowtask')
def airflowtask():
    # Check if validation has been performed and passed
    if not session.get('validation_passed', False):
        print("Validation hasn't been passed, redirecting to index")
        # Set error message
        session['validation_errors'] = {
            'general': "Please complete the form validation before accessing Airflow Task"
        }
        # Redirect back to front page
        return redirect(url_for('index'))
    
    # Get values from session
    ms_id = session.get('ms_id')
    password = session.get('password')
    base_tables = [item.strip() for item in session.get('base_table', '').split(',')]
    src_sys_cds = [item.strip() for item in session.get('src_sys_cd', '').split(',')]
    batch_names = [item.strip() for item in session.get('batch_name', '').split(',')]
    
    # Generate Airflow DAG content for each table
    tables_data = []
    
    for i in range(len(base_tables)):
        base_table = base_tables[i]
        src_sys_cd = src_sys_cds[i] if i < len(src_sys_cds) else src_sys_cds[-1]
        batch_name = batch_names[i] if i < len(batch_names) else batch_names[-1]
        
        # Generate Airflow DAG Python code
        dag_code = f"""from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy_operator import DummyOperator
from datetime import datetime, timedelta

default_args = {{
    'owner': '{ms_id}',
    'depends_on_past': False,
    'start_date': datetime(2023, 1, 1),
    'email': ['{ms_id}@company.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}}

dag = DAG(
    '{batch_name}_DAG',
    default_args=default_args,
    description='DAG for {src_sys_cd} {base_table} ETL process',
    schedule_interval='0 */12 * * *',
    catchup=False
)

start = DummyOperator(
    task_id='start',
    dag=dag
)

load_prebase = PythonOperator(
    task_id='load_prebase_table',
    python_callable=load_prebase_fn,
    op_kwargs={{'src_sys_cd': '{src_sys_cd}', 'table_name': '{base_table}'}},
    dag=dag
)

load_cf = PythonOperator(
    task_id='load_cf_table',
    python_callable=load_cf_fn,
    op_kwargs={{'src_sys_cd': '{src_sys_cd}', 'table_name': '{base_table}'}},
    dag=dag
)

end = DummyOperator(
    task_id='end',
    dag=dag
)

start >> load_prebase >> load_cf >> end"""
        
        # Add to tables data
        tables_data.append({
            'id': i,
            'name': base_table,
            'code': dag_code,
            'src_sys_cd': src_sys_cd,
            'batch_name': batch_name
        })
    
    # Convert tables_data to JSON for JavaScript usage
    tables_json = json.dumps(tables_data)
    
    print(f"Rendering Airflow Task with {len(tables_data)} DAGs")
    
    return render_template('airflowtask.html', 
                          ms_id=ms_id,
                          base_table=session.get('base_table'),
                          src_sys_cd=session.get('src_sys_cd'),
                          batch_name=session.get('batch_name'),
                          tables_data=tables_data,
                          tables_json=tables_json)

if __name__ == '__main__':
    app.run(debug=True)