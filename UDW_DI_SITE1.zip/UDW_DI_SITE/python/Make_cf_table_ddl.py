def create_cf_table_ddl(src_sys_cd, base_table_name, original_ddl):
    # Extract the original table name from the DDL
    original_table_name = base_table_name
    
    # Create the new table name
    new_table_name = f"{src_sys_cd}_{base_table_name}_cf"
    
    # Replace the original table name with the new table name in the DDL
    new_ddl = original_ddl.replace(original_table_name, new_table_name, 1)
    
    return new_ddl

# Example usage
src_sys_cd = 'your_src_sys_cd'
base_table_name = 'your_base_table_name'
original_ddl = """
CREATE SET TABLE UDWBASEVIEW1.your_base_table_name, NO FALLBACK,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      column1 INTEGER,
      column2 VARCHAR(255),
      column3 DATE
     )
PRIMARY INDEX ( column1 );
"""

# new_ddl = create_cf_table_ddl(src_sys_cd, base_table_name, original_ddl)
# print(new_ddl)
