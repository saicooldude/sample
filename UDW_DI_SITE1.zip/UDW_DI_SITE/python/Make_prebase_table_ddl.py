def create_prebase_table_ddl(src_sys_cd, base_table_name, original_ddl):
    """
    Creates DDL for a prebase table based on the original base table DDL.
    
    Args:
        src_sys_cd (str): Source system code
        base_table_name (str): Original base table name
        original_ddl (str): Original DDL statement
        
    Returns:
        str: Modified DDL for the prebase table
    """
    # Extract the original table name from the DDL
    original_table_name = base_table_name
    
    # Create the new prebase table name
    new_table_name = f"{src_sys_cd}_{base_table_name}_prebase"
    
    # Replace the original table name with the new prebase table name in the DDL
    new_ddl = original_ddl.replace(original_table_name, new_table_name, 1)
    
    return new_ddl